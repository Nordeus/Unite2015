﻿using UnityEngine;

public class RandomMover : MonoBehaviour
{
	public float movementSpeed = 2f;
	private Vector3 destination;

	public void Start()
	{
		SetRandomDestination();
	}

	public void Update()
	{
		transform.position = Vector3.MoveTowards(transform.position, destination, movementSpeed * Time.deltaTime);
		if (Vector3.Distance(transform.position, destination) < 0.1f)
		{
			SetRandomDestination();
		}
	}

	public void SetRandomDestination()
	{
		destination = new Vector3(Random.Range(-5, 5), Random.Range(0, 1), Random.Range(-5, 5));
	}
}