﻿
using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// A region of billboards that are pre batched. The class contains the data
/// that was used for batching, and also batches its children to be used as billboards
/// 
/// The position of the individual batched objects is stored in the normal of each vertex.
/// The mesh renderer must have a billboard material on it, or this whole thing won't work.
/// Then batching planes, take care that before batching they are oriented right, since if they are not
/// you won't be able to se any results (since you will be looking at a side of a slice of paper :D)
/// </summary>
[RequireComponent(typeof(MeshRenderer))]
public class BillboardRegion : MonoBehaviour
{
	#region Private fields and properties

	private MeshFilter meshFilter
	{
		get
		{
			MeshFilter result = GetComponent<MeshFilter>();
			if (result == null) result = gameObject.AddComponent<MeshFilter>();

			return result;
		}
	}

	#endregion
	#region Public methods

	public void Start()
	{
		// Create the billboard
		Regenerate();
	}

	/// <summary>
	/// Recreates the mesh from the meshes it was made
	/// </summary>
	public void Regenerate()
	{
		// The new mesh
		Mesh regeneratedMesh = new Mesh();

		// The data for the new mesh
		List<Vector3> vertices = new List<Vector3>();
		List<Vector2> uvs = new List<Vector2>();

		// If your mesh has color attributes, you can uncomment them here, and down in the code to batch colors as well.
		//List<Color> colors = new List<Color>();
		List<Vector4> tangents = new List<Vector4>();
		List<Vector3> normals = new List<Vector3>();
		List<int> triangles = new List<int>();

		foreach (MeshFilter filter in GetComponentsInChildren<MeshFilter>())
		{
			// Skip the owned mesh filter
			if (filter == meshFilter || filter.GetComponent<Renderer>() == null) continue;

			// NOTE FOR BATCHING OPTIMIZATION: The vertex data shouldn't be read directly from the mesh and accessed in a loop.
			// They should be first copied in a separate array and then accessed from that array, this
			// can significantly improve performance if you have issues with batching performance.

			Mesh billboardMesh = filter.sharedMesh;
			filter.GetComponent<Renderer>().enabled = false;

			// First the indices
			for (int i = 0; i < billboardMesh.triangles.Length; i++)
			{
				triangles.Add(vertices.Count + billboardMesh.triangles[i]);
			}

			Matrix4x4 transform = Matrix4x4.TRS(Vector3.zero, filter.transform.rotation, filter.transform.localScale);
			// Now all vertex data
			for (int i = 0; i < billboardMesh.vertexCount; i++)
			{
				vertices.Add(transform * billboardMesh.vertices[i]);
				tangents.Add(billboardMesh.tangents[i]);
				//colors.Add(billboardMesh.colors[i]);
				uvs.Add(billboardMesh.uv[i]);
			}
			TransferWolrdPositionToNormals(filter.transform.position, normals, billboardMesh.vertexCount);
		}

		// Apply the newly generated values
		regeneratedMesh.vertices = vertices.ToArray();
		regeneratedMesh.uv = uvs.ToArray();
		//regeneratedMesh.colors = colors.ToArray();
		regeneratedMesh.triangles = triangles.ToArray();
		regeneratedMesh.normals = normals.ToArray();
		regeneratedMesh.tangents = tangents.ToArray();

		// We need the bounds also
		RecalculateBounds(regeneratedMesh);

		if (meshFilter.sharedMesh != null) Destroy(meshFilter);
		meshFilter.sharedMesh = regeneratedMesh;

		// Add mesh renderer if it doesn't exist
		if (gameObject.GetComponent<MeshRenderer>() == null) gameObject.AddComponent<MeshRenderer>();
	}

	#endregion
	#region Prvate methods

	/// <summary>
	/// Transfers the position information to the normals list.
	/// </summary>
	/// <param name="position">The position to be transferred</param>
	/// <param name="normals">The list to which to transfer</param>
	/// <param name="vertexCount">The number of vertexes</param>
	private void TransferWolrdPositionToNormals(Vector3 position, List<Vector3> normals, int vertexCount)
	{
		for (int i = 0; i < vertexCount; i++)
		{
			normals.Add(position);
		}
	}

	/// <summary>
	/// Recalculates the bounds of the region
	/// </summary>
	private void RecalculateBounds(Mesh mesh)
	{
		MeshFilter[] filters = GetComponentsInChildren<MeshFilter>();
		Bounds newBounds = new Bounds(Vector3.zero, Vector3.one);

		for (int i = 0; i < filters.Length; i++)
		{
			if (filters[i] == meshFilter) continue;
			Bounds filterBounds = new Bounds(filters[i].transform.localPosition, filters[i].sharedMesh.bounds.size);
			newBounds.Encapsulate(filterBounds);
		}

		mesh.bounds = newBounds;
	}

	#endregion
}